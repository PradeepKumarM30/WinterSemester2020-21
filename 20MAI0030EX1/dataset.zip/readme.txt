PRADEEP KUMAR M 20MAI0030

The Zip file contains the dataset required for q.no 1 and q.no.3.
For question 1, rename the dataset to data.csv. It is already named as data.csv
For question 3, maintain the given folder structure and the root folder is named data
The structure FYI is

data –
        train – (30 images)
                    dog(15 images)
	          cat(15 images)
         test – (10 images)
                 dog(5 images)
                 cat(5 images)


Unzip the file dataset.zip in the 20MAI0030EX1 folder to obtain the dataset, paste it into the colab folder structure in the place you wish to do the 
operations on the data set. modify the commands in colab according to the folder structure you paste